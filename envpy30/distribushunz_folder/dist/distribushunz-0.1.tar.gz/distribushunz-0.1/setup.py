from setuptools import setup

setup(name='distribushunz',
      author='Lawrence Krukrubo <sisokels@gmail.com>',
      version='0.1',
      description='Statistical Moments of Gaussian and Binomial distributions',
      packages=['distribushunz'],
      zip_safe=False)